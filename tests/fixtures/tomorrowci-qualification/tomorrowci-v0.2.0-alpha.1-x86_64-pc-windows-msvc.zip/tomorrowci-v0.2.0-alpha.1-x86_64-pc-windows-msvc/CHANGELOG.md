# Changelog

All notable changes to TomorrowCI are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Changed

- Build the Windows MSVC candidate with the CRT linked statically and reject
  candidate construction if PE inspection still finds an app-local-resolvable
  `VCRUNTIME*.dll` import. This closes only that runtime-dependency gap; it does
  not grant release authorization or widen the candidate's claim scope. The
  same non-publishing gate now builds the exact pull-request head on Windows,
  resolves the active MSVC `dumpbin.exe`, and smoke-tests `trust --json`.
- Record the immutable, project-operated `v0.2.0-alpha.1` GitHub prerelease and
  anonymous exact-asset read-back for external testing. The candidate manifest
  remains unauthorized; independent authorization, protected formal promotion,
  platform qualification, and GHCR publication remain blocked.

## [0.2.0-alpha.1] - 2026-08-11

### Added

- Add content-addressed dependency manifests, exact resolved dependency sets,
  subset materialization, and observed minimal-change reduction for pip, npm,
  and cargo fixtures.
- Add a Linux Docker CI qualification gate that scans each dependency fixture,
  verifies its current-v2 evidence, and replays the minimal failing scenario
  twice with matching exit and normalized failure signature.
- Add bounded Node and Rust runtime qualification, the interactive report UI,
  and exact-commit GitHub source materialization with fail-closed controls.
- Add deterministic four-platform release-candidate archives, a reproducible
  OCI candidate, exact SBOM and vulnerability evidence, and detached candidate
  provenance without granting publication authority.
- Add strict independent-authorization and annotated-tag qualification
  verifiers. These contracts validate externally signed evidence and exact
  candidate bytes but do not publish a tag, release, or container image.
- Add result-blind preregistration for three exact-SHA public targets and a
  repository-owned Docker/Podman qualification workflow. Result authority is
  recorded separately from the preregistration contract.

### Changed

- Start the `0.2.0-alpha.1` development line for the versioned strict evidence
  inventory and fail-closed replay trust core.
- Make no-engine scans emit complete, verifiable BLOCKED evidence rather than
  leaving a partial run.
- Derive CLI, package, archive, changelog, and SBOM identity from the Cargo
  workspace version; release tags must match it exactly.
- Pin external GitHub Actions to immutable commits and replace placeholder
  dependency versions with an exact Cargo.lock CycloneDX inventory.
- Disable and retire the historical dispatchable release workflow path; build
  read-only candidates from a new workflow path that does not exist on old
  published refs.
- Normalize Windows Docker Desktop bind paths and force-remove exactly named
  containers after timeout so a killed client cannot leave target work running.
- Record the bounded M2 PASS at exact master
  `456a36edb1e8547612cd13ee7a30be3479d33bab` in CI run
  `31316809823`; at that source identity M3 runtime, Podman, platform, and
  independent external qualification remained unclaimed.
- Qualify bounded Node and Rust runtime slices on Linux Docker at exact master
  `a6af3076ed3286d42c5ed7a386cb6812d8b76c50` in CI run `31447884019`,
  including current-v2 verification, replay x2, downloaded-artifact read-back,
  and fail-closed baseline-invalid/flaky/blocked controls. Podman and the wider
  platform matrix remain unclaimed.
- Close the bounded M4 report and exact-commit remote-materialization
  engineering slices through PR #5, merge
  `f6efabff0214ef02d2287ccb870a4e2a75c8e2f0`, and successful exact-master CI
  run `31451349743`.
- Reproduce, download, and reverify the four-platform and OCI candidate from
  exact source `8ab64498add92360b92034333f056dc202396d24`, run `31479363341`,
  artifact `9096821821`. Its status remains
  `CANDIDATE_ONLY_NOT_RELEASE_AUTHORIZED`.
- Qualify all six preregistered exact-SHA Python/Node/Rust target and hosted
  Linux Docker/Podman pairs at exact source
  `8ab64498add92360b92034333f056dc202396d24` in run `31480491950`, including
  replay twice per candidate and downloaded current-v2 read-back. This is a
  project-owned observation, not independent authorization; earlier failed
  runs remain immutable history.

### Notes

- The exact candidate was later published as immutable GitHub prerelease
  `v0.2.0-alpha.1` for project-operated external testing, and its 16 assets
  passed anonymous public download read-back. No registry image is published;
  platform qualification, genuine independent authorization, and protected
  formal promotion remain blocked.

### Security

- Reject malformed, duplicate, escaping, aliased, unlisted, missing, or
  mutated evidence entries, including scenario and replay content.
- Reserve replay attempts append-only and refuse target execution when the
  existing evidence bundle fails verification.

## [0.1.1-alpha.2] - 2026-08-06

### Changed

- Evidence integrity: image tag/digest separation, phase timestamps, scenario-local venvs
- `tomorrowci verify` checksum boundary including claims.json
- Independent replay attempt artifacts under `replays/attempt-N/`
- Action structured exit handling; consumer git repository dogfood
- Package version `0.1.1-alpha.2`; acceptance-gated release workflow with prerelease

### Notes

- `v0.1.1-alpha.1` preserved as rejected acceptance candidate
- `v0.1.0` preserved as rejected product candidate

## [0.1.0] - 2026-08-06

### Added

- Domain model, config schema, verdict and breakage-horizon authorization
- Budget-aware planner, failure reruns, flaky classification, ddmin axis reduction
- Ecosystem adapters: Python (pip), Node (npm), Rust (cargo)
- Docker/Podman sandbox executor with safe defaults (no host target execution)
- Evidence bundles with checksums, replay scripts, HTML/JSON/SARIF reports
- Scan metrics instruments and claim-to-evidence ledger
- Trust-behavior audit (`tomorrowci trust`)
- GitHub composite Action, job summary, base/head horizon compare + policy gate
- Fixtures: python-runtime-break, python-dependency-break, node-dependency-break, rust-msrv-break
- Release dry-run tooling and documentation suite for public v0.1

### Security

- Privileged containers and docker.sock mounts rejected by policy
- Fetch/test network phases separated; secrets scrubbed from container env
- HTML report escapes untrusted content; ANSI stripped from logs

### Known limitations

- Live container e2e requires a running Docker/Podman daemon
- yarn/pnpm, poetry, and remote GitHub clone scan are unsupported or incomplete
- SBOM/signing use cargo-based dry-run scripts; full SLSA provenance is documented as future work
